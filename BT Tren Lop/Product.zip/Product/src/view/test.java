
package view;

import Product.Product;
import model.ProductDB;


public class test{

    public static void main(String[] args) {
        Product a = new Product("P001");        
        System.out.println(a); 
        System.out.println(a.getName());
       
    }    
}
