create database PRJ321_DE130119
go
use PRJ321_DE130119
go
create table Product_DE130119(
ProductID varchar(5) primary key not null,
ProductName varchar(50) not null,
Unit varchar(10) not null,
Price float not null)
go
insert into Product_DE130119
values('P001','Samsung Galaxy 10','Set',12000000),
('P002','Iphone 12X','Item',24000000)
go