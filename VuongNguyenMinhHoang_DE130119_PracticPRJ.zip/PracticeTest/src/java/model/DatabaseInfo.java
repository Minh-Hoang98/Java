
package model;

public interface DatabaseInfo {
    public static String driverName="com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static String dbURL="jdbc:sqlserver://Mr_Css:1433;databaseName=PRJ321_DE130119;";
    public static String userDB="se1305";
    public static String passDB="abcd";
}
