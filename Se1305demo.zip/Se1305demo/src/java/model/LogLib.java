
package model;

import java.time.LocalDate;


public class LogLib {
    private int LogID;
    private LocalDate ngayDat, ngayMuon, ngayPTra, ngayTra;
}
