
package model;

import java.util.ArrayList;
import java.util.Vector;

public class LogLibDB {
 //---------------------------------------------------------------------------------------
    public static LogLib getLog(int logID){
        return null;
    }
 //---------------------------------------------------------------------------------------
    public static void updateLog(LogLib log){
        
    }
 //---------------------------------------------------------------------------------------
    public static int writeLog(LogLib log){
        return -1;
    }
 //---------------------------------------------------------------------------------------   
    public static Vector<Vector> viewLogByUser(String uid){
        return null;
    }
 //---------------------------------------------------------------------------------------   
    public static ArrayList<LogLib> getLogsByUser(String uid){
        return null;
    }
}

